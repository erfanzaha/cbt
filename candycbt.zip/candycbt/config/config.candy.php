<?php
$copyright = 'Candy CBT';

define("VERSI", "2.9.2");
define("REVISI", "1");
define("APLIKASI", "X-Candy CBT");
define("NAMA_DATABASE", "cbtcandy28");
define("VERSI_DB", "2.9.2");
define("BASEPATH", "cbtcandy");
