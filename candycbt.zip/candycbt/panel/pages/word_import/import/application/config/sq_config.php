<?php
//include "../../../../config/config.database.php";
$sq_base_url = '';
$sq_hostname = 'localhost';
$sq_dbname = 'xcandyr4';
$sq_dbusername = 'root';
$sq_dbpassword = '';
